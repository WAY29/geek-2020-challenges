#!/bin/sh
sleep 3
service apache2 start
touch > /started
bash
